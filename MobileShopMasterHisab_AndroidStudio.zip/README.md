# Mobile Shop Master Hisab — Android Studio Project

This is a complete Android Studio project wrapping the supplied offline HTML app in an Android WebView.

## Build APK

1. Install Android Studio on Windows/Mac/Linux.
2. Open this folder:
   `MobileShopMasterHisab`
3. Let Gradle sync/download the Android dependencies.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be generated under:
   `app/build/outputs/apk/debug/app-debug.apk`

## Release APK

Use:
**Build > Generate Signed App Bundle / APK > APK**

The app works offline and keeps its records using the web app's localStorage on the phone.

Application ID:
`com.mobileshopmaster.hisab`

Version:
`1.0 (1)`

Minimum Android:
Android 6.0 / API 23
